import { Component, OnInit } from '@angular/core';
import { DataCls } from '../data-cls';
import { Books } from '../books';

@Component({
  selector: 'app-book-comp',
  templateUrl: './book-comp.component.html',
  styleUrls: ['./book-comp.component.css']
})

export class BookCompComponent implements OnInit {
  bname: string;
  bauthor: string;
  bpubs: string;

  dcls: DataCls;
  bArr: Books[];

  constructor() {
    this.dcls = new DataCls();
    this.bArr = new Array<Books>();
  }

  onClick(e) {
    let aa = new Books(this.bname, this.bauthor, this.bpubs);
    this.dcls.addBooks(aa);
    this.bArr = this.dcls.retBooks();

    this.bname='';
    this.bauthor='';
    this.bpubs='';

  }

  ngOnInit() {
  }

}
