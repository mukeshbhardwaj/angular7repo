import { Component, OnInit } from '@angular/core';
import { Books } from '../books';
import { Person } from "../Person";
import { DataCls } from '../data-cls';

@Component({
  selector: 'app-testcomp',
  templateUrl: './testcomp.component.html',
  styleUrls: ['./testcomp.component.css']
})
export class TestcompComponent implements OnInit {

  t: string;
  book: Books;
  persons: Person[];
  
  constructor() {
    this.persons = new Array<Person>();
    var dcls = new DataCls();
    this.persons = dcls.retArr();
  }

  ngOnInit() {
  }

  onSel() {
    console.log(this.t);
  }

  onSub(a, b) {
    console.log(a, b);
  }

  clk(a, b, c) {
    this.book = new Books(a, b, c);
  }

}
