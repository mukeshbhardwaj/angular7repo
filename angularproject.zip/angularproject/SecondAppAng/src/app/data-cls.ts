import { Person } from './person';
import { Books } from './books';

export class DataCls {
    private _pArr:Person[];

    public retArr():Person[]{
        this._pArr= new Array<Person>();
        var arr1=['Krishna','Radha','Radhika','Brindavan','Kirishnapriya'];
        var arr2=['Krishna@yahoo.com','Radha@yahoo.com','Radhika@yahoo.com','Brindavan@yahoo.com','Kirishnapriya@yahoo.com'];
        var arr3=['53456868','454465464','456565448','1444444','55555555'];
    

        for (let i=0; i<arr1.length; i++) {
        var per=new Person(arr1[i],arr2[i],arr3[i]);
            this._pArr.push(per);
        }

        return this._pArr;
}

private _bArr:Books[]=new Array<Books>();

public retBooks():Books[]{
    return this._bArr;
}

public addBooks(bb:Books):void{
    this._bArr.push(bb)
}

}