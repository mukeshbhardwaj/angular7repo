export class Books {
    name:string;
    author:string;
    publisher:string;

    constructor(a:string,b:string,c: string){
        this.name=a;
        this.author=b;
        this.publisher=c;
    }

}
