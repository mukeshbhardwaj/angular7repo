export class Person {
    private _name: string;
    private _email: string;
    private _phone: string;

    constructor(a:string,b: string,c:string){
        this._name=a;
        this._email=b;
        this._phone=c;
            }
        

public getName(): string{
    return this._name;
}

public getEmail(): string{
    return this._email;
}

public getPhone(): string{
    return this._phone;
}
}
