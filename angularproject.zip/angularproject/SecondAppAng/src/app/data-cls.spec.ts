import { DataCls } from './data-cls';

describe('DataCls', () => {
  it('should create an instance', () => {
    expect(new DataCls()).toBeTruthy();
  });
});
