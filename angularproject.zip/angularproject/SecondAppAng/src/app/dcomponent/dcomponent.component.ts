import { Component, OnInit } from '@angular/core';
import { Person } from '../person';
import { DataCls } from '../data-cls';

@Component({
  selector: 'app-dcomponent',
  templateUrl: './dcomponent.component.html',
  styleUrls: ['./dcomponent.component.css']
})
export class DcomponentComponent implements OnInit {

  pp: Person[];

  constructor() {
    this.pp=new Array<Person>();
    let dd=new DataCls();
    this.pp=dd.retArr();
    console.log(this.pp)
   }

  ngOnInit() {
  }

}
