import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ccomp',
  templateUrl: './ccomp.component.html',
  styleUrls: ['./ccomp.component.css']
})
export class CcompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
