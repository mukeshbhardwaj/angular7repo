import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'to web page';
  g="Hello friend whats up";
  g1="welcome to angular7";
  ctitle="google share";
  ctext="google";
  cline=" google link";
}
