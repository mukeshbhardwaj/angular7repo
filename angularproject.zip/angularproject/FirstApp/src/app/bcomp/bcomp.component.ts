import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bcomp',
  templateUrl: './bcomp.component.html',
  styleUrls: ['./bcomp.component.css']
})
export class BcompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
