import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms';

export class Register{
  username:string;
  password:string;
  email:string;
  mobile:string;
  aadhar:string;

  constructor(a:string,b:string,c:string,d:string,e:string){

    this.username=a;
    this.password=b;
    this.email=c;
    this.mobile=d;
    this.aadhar=e;
  }
}



@Component({
  selector: 'app-form-comp',
  templateUrl: './form-comp.component.html',
  styleUrls: ['./form-comp.component.css']
})
export class FormCompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


  onSub(v){
let obj=console.log(v.username,v.password,v.email,v.mobile,v.aadhar);
console.log(JSON.stringify(obj));
  }
}
