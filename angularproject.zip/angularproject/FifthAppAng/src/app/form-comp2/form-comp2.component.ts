import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl, Validators} from '@angular/forms'

@Component({
  selector: 'app-form-comp2',
  templateUrl: './form-comp2.component.html',
  styleUrls: ['./form-comp2.component.css']
})
export class FormComp2Component implements OnInit {
  MyLogin: FormGroup;
  email:FormControl;
  password:FormControl;
  mobile:FormControl;
  aadhar:FormControl;

  constructor() { }

  ngOnInit() {
    this.MyLogin=new FormGroup({
      email:new FormControl("",Validators.required),
      password:new FormControl("",Validators.required), 
      mobile:new FormControl("",Validators.required),
      aadhar:new FormControl("",Validators.required)   
    });
  }
onFormSubmit(){
  if(this.MyLogin.valid){
    console.log(JSON.stringify(this.MyLogin.value))
  }
}


}
