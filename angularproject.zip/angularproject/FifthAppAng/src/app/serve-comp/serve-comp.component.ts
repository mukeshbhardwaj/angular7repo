import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';


@Component({
  selector: 'app-serve-comp',
  templateUrl: './serve-comp.component.html',
  styleUrls: ['./serve-comp.component.css']
})
export class ServeCompComponent implements OnInit {
data;
  constructor(private http: HttpClient) {

   }

  ngOnInit() {
    // this.http.get('https://jsonplaceholder.typicode.com/todos').subscribe((a)=>{
    //   this.data=a
    // })
  }

  fun1(v) {
    this.http.get('https://jsonplaceholder.typicode.com/todos/'+v).subscribe((a)=>{
      this.data=a
    })
  }

}
