import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServeCompComponent } from './serve-comp.component';

describe('ServeCompComponent', () => {
  let component: ServeCompComponent;
  let fixture: ComponentFixture<ServeCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServeCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServeCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
