import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mat-comp',
  templateUrl: './mat-comp.component.html',
  styleUrls: ['./mat-comp.component.css']
})
export class MatCompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
