import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {
  MatCardModule, MatDialogModule, MatInputModule, MatTableModule,
  MatToolbarModule, MatMenuModule, MatChipsModule, MatNativeDateModule, MatIconModule, MatProgressSpinnerModule, MatDatepickerModule
} from '@angular/material';
import { MatCompComponent } from './mat-comp/mat-comp.component';

@NgModule({
  declarations: [
    AppComponent,
    MatCompComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
      MatCardModule, MatDialogModule, MatInputModule, MatTableModule,
      MatToolbarModule, MatMenuModule, MatChipsModule, MatNativeDateModule, MatIconModule, MatProgressSpinnerModule, MatDatepickerModule
      ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
