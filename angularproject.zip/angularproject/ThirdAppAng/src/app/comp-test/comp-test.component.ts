import { Component, OnInit } from '@angular/core';
import {MyDirectiveDirective } from '../my-directive.directive'
import{MyServiceService} from '../my-service.service'
import { CreditCard } from '../credit-card';

@Component({
  selector: 'app-comp-test',
  templateUrl: './comp-test.component.html',
  styleUrls: ['./comp-test.component.css'],
  providers:[MyServiceService]
})
export class CompTestComponent implements OnInit {

  PStr:number;
  astr: string;

  cArr:CreditCard[];
  nArr:number[];
  
  constructor(private serve:MyServiceService) { 
    this.nArr=new Array<number>(100,200,300,625,49);
    // serve.retCArr().forEach(a=>console.log(JSON.stringify(a)));
    this.cArr=new Array<CreditCard>();
    serve.retCArr().forEach(a => this.cArr.push(a));
  }

  ngOnInit() {
  }

}
