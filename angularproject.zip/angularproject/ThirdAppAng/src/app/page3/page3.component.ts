import { Component, OnInit } from '@angular/core';



export class Computer {
  name: string;
  brand: string;
  ram: number;
  constructor(a: string, b: string, c: number) {
    this.name = a;
    this.brand = b;
    this.ram = c;
  }
}

@Component({
  selector: 'app-page3',
  templateUrl: './page3.component.html',
  styleUrls: ['./page3.component.css']
})




export class Page3Component implements OnInit {
oArr: Computer[];

  arr1: string[];
  arr2: string[];
  arr3: number[];
  constructor() {
    this.oArr=new Array<Computer>();

    var arr1 = ['Ex10', 'J44', 'T55', 'F77', 'L20'];
    var arr2 = ['Gatway', 'Hp', 'Dell', 'ASUS0', 'Datawind'];
    var arr3 = [1, 2, 2, 3, 3, 5, 5,];

    for (let i = 0; i < arr1.length; i++) {
      let aa = new Computer(arr1[i], arr2[i], arr3[i]);
    }
  }

  ngOnInit() {
  }

}
