import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TCompCComponent } from './tcomp-c.component';

describe('TCompCComponent', () => {
  let component: TCompCComponent;
  let fixture: ComponentFixture<TCompCComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TCompCComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TCompCComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
