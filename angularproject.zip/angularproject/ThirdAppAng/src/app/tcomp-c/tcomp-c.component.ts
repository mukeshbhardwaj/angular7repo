import { Component, OnInit, Input } from '@angular/core';
import {MyPipe3Pipe} from "../my-pipe3.pipe";

@Component({
  selector: 'app-tcomp-c',
  templateUrl: './tcomp-c.component.html',
  styleUrls: ['./tcomp-c.component.css']
})
export class TCompCComponent implements OnInit {

  @Input() PStr: number;
  constructor() { }

  ngOnInit() {
  }

}
