import { CreditCard } from './credit-card';

describe('CreditCard', () => {
  it('should create an instance', () => {
    expect(new CreditCard()).toBeTruthy();
  });
});
