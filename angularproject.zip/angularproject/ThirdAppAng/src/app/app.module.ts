import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { Page1Component } from './page1/page1.component';
import { Page2Component } from './page2/page2.component';
import { Page3Component } from './page3/page3.component';
import { Page4Component } from './page4/page4.component';
import { Page5Component } from './page5/page5.component';
import { RouterModule,Router} from "@angular/router";

import { FormsModule } from '@angular/forms';
import { CompTestComponent } from './comp-test/comp-test.component';
import { MyPipePipe } from './my-pipe.pipe';
import { MyPipe2Pipe } from './my-pipe2.pipe';
import { MyPipe3Pipe } from './my-pipe3.pipe';
import { TCompAComponent } from './tcomp-a/tcomp-a.component';
import { TCompBComponent } from './tcomp-b/tcomp-b.component';
import { TCompCComponent } from './tcomp-c/tcomp-c.component';
import { MyDirectiveDirective } from './my-directive.directive';
import { MyServiceService} from './my-service.service';

@NgModule({
  declarations: [
    AppComponent,
    Page1Component,
    Page2Component,
    Page3Component,
    Page4Component,
    Page5Component,
    CompTestComponent,
    MyPipePipe,
    MyPipe2Pipe,
    MyPipe3Pipe,
    TCompAComponent,
    TCompBComponent,
    TCompCComponent,
    MyDirectiveDirective
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot([
      {
        path:'Page1',component: Page1Component
      },
      {
        path:'Page2',component: Page2Component
      },
      {
        path:'Page3',component: Page3Component
      },
      {
        path:'Page4',component: Page4Component
      },
      {
        path:'Page5',component: Page5Component
      }
    ])
  ],
  providers: [MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
