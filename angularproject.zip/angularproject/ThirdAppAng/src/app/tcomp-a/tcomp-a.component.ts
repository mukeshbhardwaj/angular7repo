import { Component, OnInit, Input } from '@angular/core';
import { MyPipePipe} from "../my-pipe.pipe"


@Component({
  selector: 'app-tcomp-a',
  templateUrl: './tcomp-a.component.html',
  styleUrls: ['./tcomp-a.component.css']
})
export class TCompAComponent implements OnInit {

  @Input() PStr:number;
  
  constructor() { }

  ngOnInit() {
  }

}
