import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TCompAComponent } from './tcomp-a.component';

describe('TCompAComponent', () => {
  let component: TCompAComponent;
  let fixture: ComponentFixture<TCompAComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TCompAComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TCompAComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
