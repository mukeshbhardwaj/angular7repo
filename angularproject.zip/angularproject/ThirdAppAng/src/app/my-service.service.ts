import { Injectable } from '@angular/core';
import { CreditCard} from "./Credit-Card";

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {

  cArr:CreditCard[];
  constructor() { 
    this.cArr=new Array<CreditCard>();
  }

retCArr():CreditCard[]{
  var arr1=['mukesh','bhardwaj','kumar','Harry'];
  var arr2=['bank of America','bank of baroda','Bank of new york','Wells Fargo'];
var arr3=['12/2/2012','1/4/2012','12/5/2015','12/12/2019','10/2/2020'];

for(let i=0;i<arr1.length;i++){
let aa=new CreditCard(arr1[i],arr2[i],arr3[i]);
this.cArr.push(aa);
}
return this.cArr;
}

retOne(a:string):CreditCard{
  var aa=new CreditCard('','','');
  var ar1=this.retCArr();
  for(let i=0;i<ar1.length;i++){
var p=ar1[i];
if(p.cname==a){
aa=p
break
}
  }
  return aa;
}

}
