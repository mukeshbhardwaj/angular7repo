import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css']
})
export class Page1Component implements OnInit {

  tArr: string[];
  constructor() { 
    this.tArr=new Array<string>('krishan','radha','radhika','brajbhumi','brindavan');
  }

  ngOnInit() {
  }

}
