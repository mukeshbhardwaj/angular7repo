import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myPipe2'
})
export class MyPipe2Pipe implements PipeTransform {

  transform(value: number, args?: any): number {
 let a=Math.pow(value,2);
    return a;
  }

}
