import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TCompBComponent } from './tcomp-b.component';

describe('TCompBComponent', () => {
  let component: TCompBComponent;
  let fixture: ComponentFixture<TCompBComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TCompBComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TCompBComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
