import { Component, OnInit, Input } from '@angular/core';
import { MyPipe2Pipe } from "../my-pipe2.pipe";

@Component({
  selector: 'app-tcomp-b',
  templateUrl: './tcomp-b.component.html',
  styleUrls: ['./tcomp-b.component.css']
})
export class TCompBComponent implements OnInit {

  @Input() PStr: number;
  constructor() { }

  ngOnInit() {
  }

}
