import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myPipe'
})
export class MyPipePipe implements PipeTransform {

  transform(value: number, args?: any): number {
    let a=Math.sqrt(value)
    return a;
  }

}
