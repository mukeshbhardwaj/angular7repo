import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appMyDirective]'
})
export class MyDirectiveDirective {

  constructor(e: ElementRef) {
    e.nativeElement.innerText="Hare Krishana";
   }

}
