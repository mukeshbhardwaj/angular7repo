import { MyPipe3Pipe } from './my-pipe3.pipe';

describe('MyPipe3Pipe', () => {
  it('create an instance', () => {
    const pipe = new MyPipe3Pipe();
    expect(pipe).toBeTruthy();
  });
});
