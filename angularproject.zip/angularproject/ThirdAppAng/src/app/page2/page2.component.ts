import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page2',
  templateUrl: './page2.component.html',
  styleUrls: ['./page2.component.css']
})
export class Page2Component implements OnInit {
nArr:number[];
  constructor() {
    this.nArr=new Array<number>(123456789,11111111,22222222,333333,444444);
   }

  ngOnInit() {
  }

}
