export class CreditCard {
    cname: string;
    bank: string;
    edt: string;
    
    constructor(a: string, b: string, c: string) {
        this.cname = a;
        this.bank = b;
        this.edt = c;
    }
}
