import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myPipe3'
})
export class MyPipe3Pipe implements PipeTransform {

  transform(value: number, args?: any): number {
    let a=Math.log(value);
    return a;
  }

}
